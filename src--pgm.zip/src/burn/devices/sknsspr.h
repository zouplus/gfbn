void skns_sprite_kludge(INT32 x, INT32 y);
void skns_draw_sprites(UINT16 *bitmap, UINT32* spriteram_source, INT32 spriteram_size, UINT8* gfx_source, INT32 gfx_length, UINT32* sprite_regs, INT32 disable_priority);
void skns_init();
void skns_exit();
