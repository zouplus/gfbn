void K007452Init();
void K007452Exit();
void K007452Scan(INT32 nAction);
void K007452Reset();

UINT8 K007452Read(UINT16 address);
void K007452Write(UINT16 address, UINT8 data);
