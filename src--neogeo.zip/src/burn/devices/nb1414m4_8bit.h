void nb_1414m4_init8b();
void nb_1414m4_scan8b();
void nb_1414m4_exec8b(UINT16 mcu_cmd,UINT8 *vram,UINT16 *scrollx,UINT16 *scrolly,INT32 emakimode);

extern UINT8 *nb1414_blit_data8b;
extern UINT32 nb1414_frame8b;

